﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace slepa_mapa
{
    public class MapPoint
    {
        public string Name { get; set; }
        public double XPercent { get; set; }
        public double YPercent { get; set; }
    }
}
