﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace slepa_mapa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint() { Name = "Praha", XPercent = 0.385, YPercent = 0.375 },
            new MapPoint() { Name = "Brno", XPercent = 0.715, YPercent = 0.71 },
            new MapPoint() { Name = "Ostrava", XPercent = 0.93, YPercent = 0.44 },
            new MapPoint() { Name = "Plzeň", XPercent = 0.2, YPercent = 0.49 },
            //new MapPoint() { Name = "Liberec", XPercent = 0.45, YPercent = 0.25 },
            //new MapPoint() { Name = "Olomouc", XPercent = 0.65, YPercent = 0.5 },
            //new MapPoint() { Name = "Ústí nad Labem", XPercent = 0.35, YPercent = 0.2 },
            //new MapPoint() { Name = "Hradec Králové", XPercent = 0.5, YPercent = 0.3 },
            //new MapPoint() { Name = "Pardubice", XPercent = 0.55, YPercent = 0.35 },
            //new MapPoint() { Name = "České Budějovice", XPercent = 0.4, YPercent = 0.65 },
            //new MapPoint() { Name = "Jihlava", XPercent = 0.5, YPercent = 0.45 },
            //new MapPoint() { Name = "Zlín", XPercent = 0.7, YPercent = 0.6 },

        };

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DrawPoints();
        }

        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawPoints();
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = point.Name,
                    Tag = point
                };

                btn.Click += Btn_Click;

                Canvas.SetLeft(btn, x);
                Canvas.SetTop(btn, y);

                OverlayCanvas.Children.Add(btn);
            }
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            MapPoint point = btn.Tag as MapPoint;

            MessageBox.Show(point.Name);
        }
        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(MapImage);

            double xPercent = pos.X / MapImage.ActualWidth;
            double yPercent = pos.Y / MapImage.ActualHeight;

            MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
        }
    }
}